package com.ecommerce.enums;

public enum OrderStatus {
    Pending,
    Placed,
    Shipped,
    Delivered
}
