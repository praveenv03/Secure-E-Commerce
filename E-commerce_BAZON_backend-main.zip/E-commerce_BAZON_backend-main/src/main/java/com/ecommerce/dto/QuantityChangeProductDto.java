package com.ecommerce.dto;

import lombok.Data;

@Data
public class QuantityChangeProductDto {

    private Long productId;

    private Long userId;

}
